const express = require('express');
const fs = require('fs');
const path = require('path');
const multer = require('multer');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, 'data', 'db.json');
const UPLOAD_DIR = path.join(__dirname, 'public', 'uploads');

// Ensure directories exist
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

// Multer storage setup for image uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, UPLOAD_DIR);
  },
  filename: function (req, file, cb) {
    const ext = path.extname(file.originalname);
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'img-' + uniqueSuffix + ext);
  }
});
const upload = multer({
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Hanya file gambar yang diperbolehkan!'));
    }
  }
});

// Middleware
app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ extended: true, limit: '20mb' }));
app.use(express.static(path.join(__dirname, 'public'), { dotfiles: 'allow' }));

// Database helper functions
function readDb() {
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error reading db:', err);
    return null;
  }
}

function writeDb(data) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (err) {
    console.error('Error writing db:', err);
    return false;
  }
}

// Public API routes
app.get('/api/data', (req, res) => {
  const db = readDb();
  if (!db) return res.status(500).json({ error: 'Gagal membaca database' });

  // Return public subset
  res.json({
    settings: db.settings,
    profile: db.profile,
    upskilling: db.upskilling,
    ekstrakurikuler: db.ekstrakurikuler,
    programSekolah: db.programSekolah,
    news: db.news,
    fasilitas: db.fasilitas
  });
});

// Public PPDB registration
app.post('/api/ppdb/register', (req, res) => {
  const db = readDb();
  if (!db) return res.status(500).json({ error: 'Gagal membaca database' });

  const { fullName, nisn, gender, birthPlace, birthDate, originSchool, majorChoice, parentName, phone, address, pathway } = req.body;

  if (!fullName || !nisn || !phone || !originSchool || !majorChoice) {
    return res.status(400).json({ error: 'Mohon lengkapi data wajib (Nama, NISN, Asal Sekolah, Jurusan, No HP/WA)' });
  }

  // Check if NISN already registered
  const existing = db.registrations.find(r => r.nisn === nisn);
  if (existing) {
    return res.status(409).json({ 
      error: `NISN ${nisn} sudah terdaftar dengan Nomor Pendaftaran: ${existing.registrationNo}. Silakan cek status pendaftaran Anda.` 
    });
  }

  const count = (db.registrations.length + 1).toString().padStart(3, '0');
  const regNumber = `PPDB-2026-${count}`;

  const newReg = {
    id: 'reg-' + Date.now(),
    registrationNo: regNumber,
    fullName: fullName.trim(),
    nisn: nisn.trim(),
    gender: gender || 'Laki-laki',
    birthPlace: birthPlace || '',
    birthDate: birthDate || '',
    originSchool: originSchool.trim(),
    majorChoice: majorChoice.trim(),
    parentName: parentName || '',
    phone: phone.trim(),
    address: address || '',
    pathway: pathway || 'Reguler',
    status: 'Menunggu Verifikasi',
    createdAt: new Date().toISOString(),
    notes: 'Pendaftaran mandiri melalui website. Mohon simpan bukti nomor pendaftaran ini.'
  };

  db.registrations.unshift(newReg);
  writeDb(db);

  res.status(201).json({
    success: true,
    message: 'Pendaftaran berhasil dikirim!',
    data: newReg
  });
});

// Check registration status by NISN or Reg No
app.get('/api/ppdb/check/:query', (req, res) => {
  const db = readDb();
  if (!db) return res.status(500).json({ error: 'Gagal membaca database' });

  const q = req.params.query.trim().toLowerCase();
  const found = db.registrations.find(r => 
    r.nisn.toLowerCase() === q || 
    r.registrationNo.toLowerCase() === q ||
    (r.phone && r.phone.replace(/\D/g, '') === q.replace(/\D/g, ''))
  );

  if (!found) {
    return res.status(404).json({ error: 'Data pendaftaran tidak ditemukan. Pastikan NISN atau No Pendaftaran sudah sesuai.' });
  }

  res.json({
    success: true,
    data: found
  });
});

// Admin authentication
app.post('/api/admin/login', (req, res) => {
  const { username, password } = req.body;
  const db = readDb();
  if (!db) return res.status(500).json({ error: 'Database error' });

  if (db.adminUser && db.adminUser.username === username && db.adminUser.password === password) {
    // Generate token
    const token = 'token_' + Date.now() + '_' + Math.random().toString(36).substring(2);
    res.json({ success: true, token, user: { username } });
  } else {
    res.status(401).json({ error: 'Username atau password admin salah!' });
  }
});

// Admin full data
app.get('/api/admin/data', (req, res) => {
  const db = readDb();
  if (!db) return res.status(500).json({ error: 'Database error' });
  res.json(db);
});

// Admin update settings (Hero, Contact, Google Form URLs, etc)
app.put('/api/admin/settings', (req, res) => {
  const db = readDb();
  if (!db) return res.status(500).json({ error: 'Database error' });

  db.settings = { ...db.settings, ...req.body };
  writeDb(db);
  res.json({ success: true, settings: db.settings });
});

// Admin update profile
app.put('/api/admin/profile', (req, res) => {
  const db = readDb();
  if (!db) return res.status(500).json({ error: 'Database error' });

  db.profile = { ...db.profile, ...req.body };
  writeDb(db);
  res.json({ success: true, profile: db.profile });
});

// Admin news CRUD
app.post('/api/admin/news', (req, res) => {
  const db = readDb();
  if (!db) return res.status(500).json({ error: 'Database error' });

  const { title, category, date, image, summary, content } = req.body;
  if (!title || !content) {
    return res.status(400).json({ error: 'Judul dan konten berita wajib diisi' });
  }

  const newArticle = {
    id: 'news-' + Date.now(),
    title,
    category: category || 'Berita',
    date: date || new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }),
    image: image || '/images/banner-reference.jpg',
    summary: summary || (content.substring(0, 150) + '...'),
    content
  };

  db.news.unshift(newArticle);
  writeDb(db);
  res.status(201).json({ success: true, news: newArticle });
});

app.put('/api/admin/news/:id', (req, res) => {
  const db = readDb();
  if (!db) return res.status(500).json({ error: 'Database error' });

  const index = db.news.findIndex(n => n.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'Berita tidak ditemukan' });

  db.news[index] = { ...db.news[index], ...req.body };
  writeDb(db);
  res.json({ success: true, news: db.news[index] });
});

app.delete('/api/admin/news/:id', (req, res) => {
  const db = readDb();
  if (!db) return res.status(500).json({ error: 'Database error' });

  db.news = db.news.filter(n => n.id !== req.params.id);
  writeDb(db);
  res.json({ success: true, message: 'Berita berhasil dihapus' });
});

// Admin program keahlian & ekskul
app.put('/api/admin/program-keahlian', (req, res) => {
  const db = readDb();
  if (!db) return res.status(500).json({ error: 'Database error' });

  const { upskilling, ekstrakurikuler } = req.body;
  if (upskilling) db.upskilling = upskilling;
  if (ekstrakurikuler) db.ekstrakurikuler = ekstrakurikuler;

  writeDb(db);
  res.json({ success: true, upskilling: db.upskilling, ekstrakurikuler: db.ekstrakurikuler });
});

// Admin program sekolah cards CRUD
app.post('/api/admin/program-sekolah', (req, res) => {
  const db = readDb();
  if (!db) return res.status(500).json({ error: 'Database error' });

  const newProg = {
    id: Date.now(),
    title: req.body.title || 'Program Baru',
    image: req.body.image || 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=600&auto=format&fit=crop&q=80',
    icon: req.body.icon || 'star',
    desc: req.body.desc || ''
  };

  db.programSekolah.push(newProg);
  writeDb(db);
  res.json({ success: true, programSekolah: db.programSekolah });
});

app.put('/api/admin/program-sekolah/:id', (req, res) => {
  const db = readDb();
  if (!db) return res.status(500).json({ error: 'Database error' });

  const id = Number(req.params.id);
  const idx = db.programSekolah.findIndex(p => p.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Program tidak ditemukan' });

  db.programSekolah[idx] = { ...db.programSekolah[idx], ...req.body };
  writeDb(db);
  res.json({ success: true, item: db.programSekolah[idx] });
});

app.delete('/api/admin/program-sekolah/:id', (req, res) => {
  const db = readDb();
  if (!db) return res.status(500).json({ error: 'Database error' });

  const id = Number(req.params.id);
  db.programSekolah = db.programSekolah.filter(p => p.id !== id);
  writeDb(db);
  res.json({ success: true, programSekolah: db.programSekolah });
});

// Admin fasilitas CRUD
app.post('/api/admin/fasilitas', (req, res) => {
  const db = readDb();
  if (!db) return res.status(500).json({ error: 'Database error' });

  const newFas = {
    id: Date.now(),
    name: req.body.name || 'Fasilitas Baru',
    icon: req.body.icon || 'building',
    desc: req.body.desc || ''
  };

  db.fasilitas.push(newFas);
  writeDb(db);
  res.json({ success: true, fasilitas: db.fasilitas });
});

app.put('/api/admin/fasilitas/:id', (req, res) => {
  const db = readDb();
  if (!db) return res.status(500).json({ error: 'Database error' });

  const id = Number(req.params.id);
  const idx = db.fasilitas.findIndex(f => f.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Fasilitas tidak ditemukan' });

  db.fasilitas[idx] = { ...db.fasilitas[idx], ...req.body };
  writeDb(db);
  res.json({ success: true, item: db.fasilitas[idx] });
});

app.delete('/api/admin/fasilitas/:id', (req, res) => {
  const db = readDb();
  if (!db) return res.status(500).json({ error: 'Database error' });

  const id = Number(req.params.id);
  db.fasilitas = db.fasilitas.filter(f => f.id !== id);
  writeDb(db);
  res.json({ success: true, fasilitas: db.fasilitas });
});

// Admin registrations management
app.put('/api/admin/registrations/:id', (req, res) => {
  const db = readDb();
  if (!db) return res.status(500).json({ error: 'Database error' });

  const idx = db.registrations.findIndex(r => r.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Data pendaftar tidak ditemukan' });

  db.registrations[idx] = { ...db.registrations[idx], ...req.body };
  writeDb(db);
  res.json({ success: true, item: db.registrations[idx] });
});

app.delete('/api/admin/registrations/:id', (req, res) => {
  const db = readDb();
  if (!db) return res.status(500).json({ error: 'Database error' });

  db.registrations = db.registrations.filter(r => r.id !== req.params.id);
  writeDb(db);
  res.json({ success: true, message: 'Data pendaftar dihapus' });
});

// CSV Export for PPDB
app.get('/api/admin/export-ppdb', (req, res) => {
  const db = readDb();
  if (!db) return res.status(500).send('Database error');

  const headers = ['No Pendaftaran', 'Nama Lengkap', 'NISN', 'Jenis Kelamin', 'Tempat Lahir', 'Tanggal Lahir', 'Asal Sekolah', 'Jurusan Pilihan', 'Nama Orang Tua', 'No WA/HP', 'Alamat', 'Jalur', 'Status', 'Tanggal Daftar'];
  const rows = db.registrations.map(r => [
    `"${r.registrationNo}"`,
    `"${r.fullName}"`,
    `"${r.nisn}"`,
    `"${r.gender}"`,
    `"${r.birthPlace}"`,
    `"${r.birthDate}"`,
    `"${r.originSchool}"`,
    `"${r.majorChoice}"`,
    `"${r.parentName}"`,
    `"${r.phone}"`,
    `"${(r.address || '').replace(/"/g, '""')}"`,
    `"${r.pathway}"`,
    `"${r.status}"`,
    `"${new Date(r.createdAt).toLocaleString('id-ID')}"`
  ]);

  const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(e => e.join(','))].join('\r\n');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="data-pendaftar-ppdb-smk-wihdatul-ummah.csv"');
  res.send(csvContent);
});

// Admin change account credentials
app.put('/api/admin/account', (req, res) => {
  const db = readDb();
  if (!db) return res.status(500).json({ error: 'Database error' });

  const { oldPassword, newUsername, newPassword } = req.body;
  if (oldPassword !== db.adminUser.password) {
    return res.status(403).json({ error: 'Password lama salah!' });
  }

  if (newUsername) db.adminUser.username = newUsername.trim();
  if (newPassword) db.adminUser.password = newPassword.trim();

  writeDb(db);
  res.json({ success: true, message: 'Akun admin berhasil diperbarui!' });
});

// File upload endpoint
app.post('/api/admin/upload', upload.single('image'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'Tidak ada file yang diunggah' });
  }
  const relativePath = '/uploads/' + req.file.filename;
  res.json({
    success: true,
    url: relativePath,
    filename: req.file.filename
  });
});

// Serve admin and public HTML
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'), { dotfiles: 'allow' });
});

app.use((req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'), { dotfiles: 'allow' });
});

app.listen(PORT, () => {
  console.log(`Server SMK Wihdatul Ummah running on http://localhost:${PORT}`);
  console.log(`Admin Panel available on http://localhost:${PORT}/admin`);
});
